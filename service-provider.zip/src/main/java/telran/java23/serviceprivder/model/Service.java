package telran.java23.serviceprivder.model;


public class Service {
    String name;
    String description;
    Double price;
    Integer	durationInMinutes;
}
