package telran.java23.serviceprivder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicePrivderApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServicePrivderApplication.class, args);
    }
}
